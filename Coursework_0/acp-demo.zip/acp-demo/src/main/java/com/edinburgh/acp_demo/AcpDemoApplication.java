package com.edinburgh.acp_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcpDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcpDemoApplication.class, args);
	}

}
